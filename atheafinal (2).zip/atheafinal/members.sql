-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2019 at 09:21 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `member_id` int(11) NOT NULL,
  `card_number` varchar(100) NOT NULL,
  `given_name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `middlename` varchar(20) NOT NULL,
  `sex` varchar(6) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `age` int(11) NOT NULL,
  `itemname` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `kilogram` int(100) NOT NULL,
  `totalpayment` double NOT NULL,
  `rec_fname` varchar(100) NOT NULL,
  `rec_lname` varchar(100) NOT NULL,
  `rec_mname` varchar(100) NOT NULL,
  `rec_address` varchar(100) NOT NULL,
  `rec_contact` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `card_number`, `given_name`, `surname`, `middlename`, `sex`, `address`, `contact_no`, `postal_code`, `age`, `itemname`, `quantity`, `kilogram`, `totalpayment`, `rec_fname`, `rec_lname`, `rec_mname`, `rec_address`, `rec_contact`) VALUES
(18, '3', 'Lito', 'Lapid', 'D', 'Male', 'Metro Manila', '09338725932', '6000', 43, 'TSHIRT', 'quantity', 10, 200, 'Thea', 'Alonso', 'A', 'Bogo Cebu City', 0),
(20, '352433', 'Rodrigez', 'Jecel', 'R', 'Male', 'Sanciangko St. Cebu City', '09338725945', '6000', 43, 'TSHIRT', 'quantity', 10, 200, 'Thea', 'Alonso', 'A', 'Bogo Cebu City', 0),
(24, '3', 'luna', 'Juan', 'a', 'Male', 'Sanciangko St. Cebu City', '09338725932', '6000', 43, 'TSHIRT', 'quantity', 10, 200, 'Thea', 'Alonso', 'A', 'Bogo Cebu City', 0),
(79, '432432', 'j', 'bbbbbb', 'kj', 'Male', 'k', 'jk', 'jk', 32, 'kj', 'quantity', 0, 0, 'jk', 'jk', 'j', 'kj', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`member_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
