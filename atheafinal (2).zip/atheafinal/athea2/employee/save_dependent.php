<?php
		include('dbcon.php');
		include('session.php');
		
		$dependent_surname = $_POST['dependent_surname'];
		$dependent_givenname = $_POST['dependent_givenname'];
		$dependent_middlename = $_POST['dependent_middlename'];
		$birthdate = $_POST['birthdate'];
		$relationship = $_POST['relationship'];
		
		$conn->query("insert into dependents
			   (dependent_surname,dependent_givenname,dependent_middlename,birthdate,relationship) 
		values ('$dependent_surname','$dependent_givenname','$dependent_middlename','$birthdate','$relationship')")or die(mysql_error());
		
		$conn->query("insert into activity_log (username,date,action) values('$user_username',NOW(),'Add dependents $given_name $surname')")or die (mysql_error());
		?>