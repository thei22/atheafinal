
		
		<?php
		include('dbcon.php');
		include('session.php');
		
		$card_number = $_POST['card_number'];
		$given_name = $_POST['given_name'];
		$surname = $_POST['surname'];
		$middlename = $_POST['middlename'];
		$sex = $_POST['sex'];
		$address = $_POST['address'];
		$contact_no = $_POST['contact_no'];
		$postal_code = $_POST['postal_code'];
		
		$age = $_POST['age'];
		$itemname = $_POST['itemname'];
		$quantity = $_POST['quantity'];
		$kilogram = $_POST['kilogram'];
		$totalpayment = $_POST['totalpayment'];
		
		$rec_fname = $_POST['rec_fname'];
		$rec_lname = $_POST['rec_lname'];
		$rec_mname = $_POST['rec_mname'];
		$rec_address = $_POST['rec_address'];
		$rec_contact = $_POST['rec_contact'];
		
		
		$conn->query("insert into members
			   (card_number,given_name,surname,middlename,sex,address,contact_no,postal_code,age,itemname,quantity,kilogram,totalpayment,rec_fname,
			   rec_lname,rec_mname,rec_address,rec_contact) 
		values ('$card_number','$given_name','$surname','$middlename','$sex','$address','$contact_no','$postal_code','$age','$itemname','$quantity','$kilogram','$totalpayment','$rec_fname',
		'$rec_lname','$rec_mname','$rec_address',
		'$rec_contact')")or die(mysql_error());
		
		$conn->query("insert into activity_log (username,date,action) values('$user_username',NOW(),'Add Member $given_name $surname')")or die (mysql_error());
	
		?>