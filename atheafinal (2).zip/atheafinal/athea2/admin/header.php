<!DOCTYPE html>
<html class="no-js">
    <head>
        <title>DONATION SYSTEM</title>
        <!-- Bootstrap -->
			<link href="images/jos.jpg" rel="icon" type="image">
			<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
			<link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
			<link href="bootstrap/css/font-awesome.css" rel="stylesheet" media="screen">
			<link href="bootstrap/css/my_style.css" rel="stylesheet" media="screen">
			<link href="bootstrap/css/print.css" rel="stylesheet" media="print">
			<link href="vendors/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
			<link href="assets/styles.css" rel="stylesheet" media="screen">
			<script src="vendors/jquery-1.9.1.min.js"></script>
			<!-- data table -->
			<link href="assets/DT_bootstrap.css" rel="stylesheet" media="screen">
			<!-- notification  -->
			<link href="vendors/jGrowl/jquery.jgrowl.css" rel="stylesheet" media="screen">
			<script src="vendors/jGrowl/jquery.jgrowl.js"></script>
    </head>
<?php include('dbcon.php'); ?>