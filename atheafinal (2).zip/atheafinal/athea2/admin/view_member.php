<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
    <body>
		<?php include('navbar.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
				<?php include('sidebar_dashboard.php'); ?>
                <div class="span9" id="">
                     <div class="row-fluid">
                        <!-- block -->
                        <div  id="block_bg" class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-right">
										<a href="members.php"><i class="icon-arrow-left icon-large"></i> Back</a>
								</div>
                            </div>
                            <div class="block-content collapse in">
												<?php
						$query = $conn->query("select * from members where member_id = '$get_id'")or die(mysql_error());
						$row = $query->fetch();
						?>
						<div class="alert alert-success"><h1>SENDER</h1></div>
						
						<div class="alert alert-success">Sender Name: <strong><?php echo $row['surname']." ".$row['given_name']." ".$row['middlename']; ?></strong></div>
						<div class="span6">
						Sender Card Number: <strong><?php echo $row['card_number']; ?></strong><br>
						Sender First Name: <strong><?php echo $row['given_name']; ?></strong><br>
						Sender Last Name: <strong><?php echo $row['surname']; ?></strong><br>
						Sender Middle Name: <strong><?php echo $row['middlename']; ?></strong><br>
						Sender Sex: <strong><?php echo $row['sex']; ?></strong><br>
						Sender Address: <strong><?php echo $row['address']; ?></strong><br>
						
						Sender Tel/Mobile Number: <strong><?php echo $row['contact_no']; ?></strong><br>
						Sender Postal Code: <strong><?php echo $row['postal_code']; ?></strong><br>
						Sender Age: <strong><?php echo $row['age']; ?></strong><br>
						Sender Brand Name / Item Name: <strong><?php echo $row['itemname']; ?></strong><br>
						
						Sender Quantity: <strong><?php echo $row['quantity']; ?></strong><br>
						Sender Kilogram: <strong><?php echo $row['kilogram']; ?></strong><br>
						Sender Total Payment: <strong><?php echo $row['totalpayment']; ?></strong>
<div class="span12">
	<hr>
						<div class="alert alert-success"><h1>RECIEVER</h1></div>
							<table cellpadding="0" cellspacing="0" border="0" class="table" id="">
		<thead>
		<tr>
					<th>Reciever Complete Name</th>
					
					<th>Reciever Address</th>
					<th>Reciever Contact</th>
					<th class="empty"></th>
		</tr>
		</thead>
		<tbody>
		<?php
		$query = $conn->query("select * from members where member_id = '$get_id'") or die(mysql_error());
		while ($row = $query->fetch()) {
		$id = $row['member_id'];
		?>
		<tr>
		<td><?php echo $row['rec_fname']." ".$row['rec_lname']." ".$row['rec_mname']; ?></td>
		<td><?php echo $row['rec_address']; ?></td> 
		<td><?php echo $row['rec_contact']; ?></td> 
		
		</tr>
	<?php } ?>    
	
		</tbody>
	</table>

</div>
							

                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>	
</html>