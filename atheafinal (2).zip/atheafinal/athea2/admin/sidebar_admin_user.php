			<div class="span3" id="sidebar">
			<img src="images/neg.png">
	<center>
		<img src="images/jos.jpg" width="250" height="200">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
						<li><a href="members.php"><i class="icon-chevron-right icon-large"></i><i class="icon-group icon-large"></i> Member Entry</a></li>
						<li  class="active"><a href="admin_user.php"><i class="icon-chevron-right icon-large"></i><i class="icon-user icon-large"></i> Admin Users</a></li>
						<li><a href="prog_user.php"><i class="icon-chevron-right icon-large"></i><i class="icon-user icon-large"></i> Program Coordinators</a></li>
						<li><a href="user_log.php"><i class="icon-chevron-right icon-large"></i><i class="icon-file icon-large"></i> User Log</a></li>
						<li><a href="activity_log.php"><i class="icon-chevron-right icon-large"></i><i class="icon-file icon-large"></i> Activity Log</a></li>
                    </ul>
	</center>
            </div>