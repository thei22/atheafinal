<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
    <body>
		<?php include('navbar.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
				<?php include('sidebar_dashboard.php'); ?>
                <div class="span9" id="">
                     <div class="row-fluid">
                        <!-- block -->
                        <div  id="block_bg" class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left"><i class="icon-pencil icon-large"></i> Edit Donation Member</div>
                                <div class="muted pull-right"><a href="members.php"><i class="icon-arrow-left icon-large"></i> Back</a></div>
                            </div>
                            <div class="block-content collapse in">
						<?php
						$query = $conn->query("select * from members where member_id = '$get_id'")or die(mysql_error());
						$row = $query->fetch();
						?>
						
						
	
						
						
						<form method="post" id="update_member">
						<!-- span 4 -->
										<div class="span4">
											<h4>Sender</h4>
											<input type="hidden" value="<?php echo $row['member_id']; ?>" class="input-block-level"  name="member_id" placeholder="Card Number" required>
											Card Number:<input type="text" value="<?php echo $row['card_number']; ?>" class="input-block-level"  name="card_number" placeholder="Card Number" required><br>
											Surname:<input type="text" value="<?php echo $row['surname']; ?>"class="input-block-level"  name="surname"     placeholder="Surname"     required><br>
											Given Name:<input type="text" value="<?php echo $row['given_name']; ?>"class="input-block-level"  name="given_name"  placeholder="Given Name"  required><br>
											Middle Name:<input type="text" value="<?php echo $row['middlename']; ?>"class="input-block-level"  name="middlename"  placeholder="Middlename"  required><br>
											
							</div>
						<!-- span 4 -->				
						<!-- span 4 -->				
						<div class="span4">
											Sex:<select name="sex" value="<?php echo $row['sex']; ?>" class="span5" required>
													
													<option>Male</option>
													<option>Female</option>
												</select>	<br>
												
										
											
											Address<input type="text" value="<?php echo $row['address']; ?>" class="input-block-level"  name="address" placeholder="address">	
											Contact No:<input type="text" value="<?php echo $row['contact_no']; ?>" class="input-block-level"  name="contact_no" placeholder="Tel/Mobile Number">				
											Postal Code<input type="text"  value="<?php echo $row['postal_code']; ?>" class="input-block-level"  name="postal_code" placeholder="Postal Code">		
										
						</div>
						<!--end span 4 -->	
						<!-- span 4 -->	<div class="span4">
										
											Age<input type="number"  value="<?php echo $row['age']; ?>"  class="input-block-level span3"  name="age" placeholder="Age" min="1" max="100" required><br>
											Item Name<input type="text"  value="<?php echo $row['itemname']; ?>"  class="input-block-level"  name="itemname" placeholder="Item Name">
											Quantity<input type="text" value="<?php echo $row['quantity']; ?>"  class="input-block-level"  name="quantity" placeholder="Quantity">
											Kilogram<input type="text" value="<?php echo $row['kilogram']; ?>"  class="input-block-level"  name="kilogram" placeholder="Kilogram">			
											Total Payment<input type="text"  value="<?php echo $row['totalpayment']; ?>" class="input-block-level"  name="totalpayment" placeholder="Total Payment">
											
						
						
						<!--
											<label>Civil Status:</label>
											<select name="civil_status" required>
												<option></option>
												<option>Single</option>
												<option>Married</option>
												<option>Widowed</option>
												<option>Separated</option>
												<option>Divorced</option>
											</select>
										<label>If Married: Name of Spouse</label>		
										<input type="text" class="input-block-level"  name="spouse_surname" placeholder="Surname">
										<input type="text" class="input-block-level"  name="spouse_given_name" placeholder="Given Name">
										<input type="text" class="input-block-level"  name="spouse_middlename" placeholder="Middlename">
										<label>If Employed:</label>		
										<input type="text" class="input-block-level"  name="name_of_employer" placeholder="Name of Employer">
											<label>Employment Status:</label>
											<select name="employment_status">
												<option></option>
												<option>Regular</option>
												<option>Contractual</option>
												<option>Seasonal</option>
											</select>
											<div class="input-prepend">
											<span class="add-on">P</span>
											<input name="ave_income" class="span" class="input-block-level span8" id="prependedInput" type="text" placeholder="Average Monthly Income">
											</div>
											-->
						</div>
						<!--end span 4 -->
						<div class="span12"><hr></div>
				
					
						<div class="span12"><hr></div>
							<table cellpadding="0" cellspacing="0" border="0" class="table" id="">
									<thead>
									<tr>
												<th>Reciever First Name</th>
												<th>Reciever Last Name</th>
												<th>Reciever Middle Name</th>
												<th>Reciever Address</th>
												<th>Reciever Contact</th>
												<th class="empty"></th>
									</tr>
									</thead>
							<tbody>
							
								<tr>
									<td><input type="text" value="<?php echo $row['rec_fname']; ?>"class="input-block-level"  name="rec_fname" placeholder="Reciever First Name"></td> 
									<td><input type="text" value="<?php echo $row['rec_lname']; ?>"class="input-block-level"  name="rec_lname" placeholder="Reciever Last Name"></td> 
									<td><input type="text" value="<?php echo $row['rec_mname']; ?>"class="input-block-level"  name="rec_mname" placeholder="Reciever Middle Name"></td> 
									<td><input type="text" value="<?php echo $row['rec_address']; ?>"class="input-block-level"  name="rec_address" placeholder="Reciever Address"></td> 
									<td><input type="text" value="<?php echo $row['rec_contact']; ?>"class="input-block-level"  name="rec_contact" placeholder="Reciever Contact"></td> 
									
									<td><button data-placement="right" title="Click to Update" id="update" name="save" class="btn btn-success"><i class="icon-save icon-large"></i> Update	</button>
                                						<script type="text/javascript">
														$(document).ready(function(){
															$('#update').tooltip('show');
															$('#update').tooltip('hide');
														});
														</script></td>
						</div>
								</tr>
								  
							</tbody>
							</table>
							</form>			
								
								
								<script>
							jQuery(document).ready(function($){
								$("#update_member").submit(function(e){
									e.preventDefault();
									var _this = $(e.target);
									var formData = $(this).serialize();
									$.ajax({
										type: "POST",
										url: "update_member.php",
										data: formData,
										success: function(html){
											$.jGrowl("Member Successfully  Updated", { header: 'Member Updated' });
											window.location = 'members.php';
										}
									});
								});
							});
							</script>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>	
</html>