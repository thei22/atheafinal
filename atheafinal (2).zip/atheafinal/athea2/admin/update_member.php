<?php
		include('dbcon.php');
		include('session.php');
		
		$member_id= $_POST['member_id'];
		$card_number = $_POST['card_number'];
		$given_name = $_POST['given_name'];
		$surname = $_POST['surname'];
		$middlename = $_POST['middlename'];
		$sex = $_POST['sex'];
		$address = $_POST['address'];
		$contact_no = $_POST['contact_no'];
		$postal_code = $_POST['postal_code'];
		
		$age = $_POST['age'];
		$itemname = $_POST['itemname'];
		$quantity = $_POST['quantity'];
		$kilogram = $_POST['kilogram'];
		$totalpayment = $_POST['totalpayment'];
		
		$rec_fname = $_POST['rec_fname'];
		$rec_lname = $_POST['rec_lname'];
		$rec_mname = $_POST['rec_mname'];
		$rec_address = $_POST['rec_address'];
		$rec_contact = $_POST['rec_contact'];
		
		
		
		$conn->query("update members set
			   card_number = '$card_number',
			   given_name = '$given_name',
			   surname = '$surname',
			   middlename = '$middlename',
			   sex = '$sex',
			   address = '$address',
			   contact_no = '$contact_no',
			   postal_code = '$postal_code',
			   age = '$age',
			   itemname = '$itemname',
			   quantity = 'quantity',
			   kilogram = '$kilogram',
			   totalpayment = '$totalpayment',
			   rec_fname = '$rec_fname',
			   rec_lname = '$rec_lname',
			   rec_mname = '$rec_mname',
			   rec_address = '$rec_address',
			   rec_contact = 'rec_contact'
			   where member_id = '$member_id'
		")or die(mysql_error());
		

		
		
		$conn->query("insert into activity_log (username,date,action) values('$user_username',NOW(),'Update Member $given_name $surname')")or die (mysql_error());
		?>
		
		
		
		
		
		