-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2019 at 09:19 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `activity_log_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`activity_log_id`, `username`, `date`, `action`) VALUES
(11, 'jkev', '2013-12-28 19:38:34', 'Add Program Coordinator'),
(12, 'jkev', '2013-12-28 19:40:27', 'Add Program Coordinator q'),
(13, 'jkev', '2013-12-28 19:47:18', 'Add Program Coordinator Stephanie  Villanueva'),
(14, 'jkev', '2013-12-28 20:00:00', 'Delete Program Coordinator John Kevin Lorayna'),
(15, 'jkev', '2013-12-28 20:00:00', 'Delete Program Coordinator Stephanie  Villanueva'),
(16, 'jkev', '2013-12-28 20:03:17', 'Add Program Coordinator q q'),
(17, 'jkev', '2013-12-28 20:04:44', 'Edit Program Coordinator q q'),
(18, 'jkev', '2013-12-29 08:45:41', 'Delete Program Coordinator q q'),
(19, 'jkev', '2013-12-29 08:46:15', 'Add Program Coordinator test test'),
(20, 'jkev', '2014-01-02 09:57:59', 'Edit Program Coordinator Brial Paul Sablan'),
(21, 'jkev', '2014-01-02 09:58:44', 'Edit Program Coordinator testq q'),
(22, 'jkev', '2014-01-02 10:00:22', 'Edit Program Coordinator Brial Paul Sablan'),
(23, 'jkev', '2014-01-02 10:01:17', 'Add Program Coordinator Christian Sausa'),
(24, 'jkev', '2014-01-02 10:29:50', 'Add Program Coordinator Achilles Palma'),
(25, 'jkev', '2014-01-02 10:36:22', 'Add Program Coordinator Stephanie Villanueva'),
(26, 'jkev', '2014-01-02 10:49:23', 'Add Member  '),
(27, 'jkev', '2014-01-02 10:51:00', 'Add Member Sherwin Laylon'),
(28, 'jkev', '2014-01-02 18:38:26', 'Add User q'),
(29, 'jkev', '2014-01-02 18:45:24', 'Add User q'),
(30, 'jkev', '2014-01-02 18:45:54', 'Add User q'),
(31, 'jkev', '2014-01-02 18:46:12', 'Add User q'),
(32, 'jkev', '2014-01-02 18:47:18', 'Edit User q'),
(33, 'jkev', '2014-01-02 18:51:27', 'Edit User qw'),
(34, 'jkev', '2014-01-02 19:20:13', 'Edit User qw'),
(35, 'jkev', '2014-01-02 19:20:36', 'Edit User qw'),
(36, 'jkev', '2014-01-02 19:21:28', 'Edit User qw'),
(37, 'jkev', '2014-01-02 19:26:05', 'Add Program Coordinator e e'),
(38, 'jkev', '2014-01-02 19:26:12', 'Delete Program Coordinator e e'),
(39, 'jkev', '2014-01-02 19:31:41', 'Add User e'),
(40, 'jkev', '2014-01-02 19:31:49', 'Delete Program Coordinator e e'),
(41, 'jkev', '2014-01-03 09:09:25', 'Update Member Rodzilq Camatoq'),
(42, 'jkev', '2014-01-03 09:10:02', 'Add Member w w'),
(43, 'jkev', '2014-01-03 09:20:06', 'Delete Member Maricon Itona'),
(44, 'jkev', '2014-01-03 09:29:26', 'Add User q'),
(45, 'jkev', '2014-01-03 09:37:51', 'Delete  User q q'),
(46, 'jkev', '2014-01-03 09:37:59', 'Edit User jkev'),
(47, 'jkev', '2014-01-03 22:30:03', 'Add Member r r'),
(48, 'jkev', '2014-01-03 22:30:13', 'Delete Member r r'),
(49, 'jkev', '2014-01-03 22:31:06', 'Add Member w w'),
(50, 'jkev', '2014-01-03 22:31:59', 'Delete Member w w'),
(51, 'jkev', '2014-01-28 19:50:56', 'Add Member Brian Paul Sablan'),
(52, 'jkev', '2014-01-28 20:40:26', 'Add Dependents q q'),
(53, 'jkev', '2014-01-28 20:53:09', 'Add Dependents b b'),
(54, 'jkev', '2014-01-28 20:53:39', 'Add Dependents k k'),
(55, 'jkev', '2014-01-28 20:53:59', 'Add Dependents l l'),
(56, 'jkev', '2014-01-22 09:03:07', 'Add Dependents q q'),
(57, 'jkev', '2014-01-22 09:03:07', 'Add Dependents q q'),
(58, 'jkev', '2014-01-22 09:08:14', 'Add Dependents e e'),
(59, 'jkev', '2014-01-22 09:08:53', 'Add Dependents k k'),
(60, 'jkev', '2014-01-22 09:11:13', 'Add Dependents l l'),
(61, 'jkev', '2014-01-22 09:11:50', 'Add Dependents m g'),
(62, 'jkev', '2014-01-22 09:15:43', 'Add Dependents j l'),
(63, 'jkev', '2014-01-22 09:15:56', 'Add Dependents m '),
(64, 'jkev', '2014-01-22 20:47:51', 'Add Dependents q q'),
(65, 'jkev', '2014-01-22 20:55:03', 'Add Dependents q q'),
(66, 'jkev', '2014-01-22 20:59:28', 'Add Member q q'),
(67, 'jkev', '2014-01-22 20:59:48', 'Add Member q q'),
(68, 'jkev', '2014-01-22 21:01:17', 'Add Dependents q q'),
(69, 'jkev', '2014-01-22 21:02:07', 'Add Dependents q q'),
(70, 'jkev', '2014-01-22 21:03:33', 'Add Dependents m m'),
(71, 'jkev', '2014-01-22 21:04:02', 'Add Dependents l l'),
(72, 'jkev', '2014-01-22 21:04:27', 'Add Dependents k k'),
(73, 'jkev', '2014-01-22 21:06:44', 'Add Dependents k l'),
(74, 'jkev', '2014-01-22 21:07:04', 'Update Member q q'),
(75, 'jkev', '2014-01-23 12:26:04', 'Add Member test test'),
(76, 'jkev', '2014-01-23 12:26:27', 'Add Dependents q q'),
(77, 'jkev', '2014-01-23 12:26:37', 'Add Dependents m m'),
(78, 'jkev', '2014-01-23 12:26:51', 'Add Dependents k u'),
(79, 'jkev', '2014-01-25 17:03:11', 'Add User m'),
(80, 'jkev', '2014-01-25 17:04:12', 'Delete  User m m'),
(81, 'jkev', '2014-01-25 17:06:14', 'Edit User tephq'),
(82, 'jkev', '2014-01-25 17:06:27', 'Edit User teph'),
(83, 'jkev', '2014-01-26 19:31:56', 'Add Dependents k k'),
(84, 'jkev', '2014-01-26 19:34:19', 'Delete Member q q'),
(85, 'jkev', '2014-01-26 19:39:46', 'Add User m'),
(86, 'jkev', '2014-01-26 19:40:12', 'Delete  User m m'),
(87, 'jkev', '2014-01-26 19:42:49', 'Edit Program Coordinator Brial Paul Sablan'),
(88, 'jkev', '2014-01-26 19:43:04', 'Delete Program Coordinator Christian Sausa'),
(89, 'jkev', '2014-01-26 19:43:34', 'Add Program Coordinator q q'),
(90, 'jkev', '2014-01-26 19:43:42', 'Delete Program Coordinator q q'),
(91, 'jkev', '2014-01-27 10:47:22', 'Add User q'),
(92, 'jkev', '2014-01-31 10:20:17', 'Delete  User Stephanie villanueva'),
(93, 'jkev', '2014-01-31 10:20:17', 'Delete  User q q'),
(94, 'jkev', '2014-01-31 10:20:28', 'Add User admin'),
(95, 'admin', '2018-12-22 02:50:10', 'Add User fd'),
(96, 'admin', '2018-12-22 02:50:22', 'Delete  User f fd'),
(97, 'admin', '2018-12-22 02:54:36', 'Add User tonzkie'),
(98, 'admin', '2018-12-22 03:26:25', 'Delete Member Sherwin Laylon'),
(99, 'admin', '2018-12-26 05:15:20', 'Add Member fsfs fdsfds'),
(100, 'admin', '2018-12-26 05:16:48', 'Delete Member fsfs fdsfds'),
(101, 'admin', '2018-12-26 05:23:36', 'Add Member kjk fds'),
(102, 'admin', '2018-12-26 05:24:53', 'Add Member JK JK'),
(103, 'admin', '2018-12-27 01:58:35', 'Add User employee'),
(104, 'employee', '2018-12-27 02:54:39', 'Add Program Coordinator leo lastitmosa'),
(105, 'employee', '2018-12-27 02:55:35', 'Delete Program Coordinator leo lastitmosa'),
(106, 'employee', '2018-12-27 02:57:17', 'Add Member k jkj'),
(107, 'employee', '2018-12-27 02:58:32', 'Delete Member k jkj'),
(108, 'employee', '2018-12-27 02:58:43', 'Delete Member JK JK'),
(109, 'employee', '2018-12-27 05:42:00', 'Add Program Coordinator fds fds'),
(110, 'admin', '2018-12-28 04:50:03', 'Add Member Thea Pulmones'),
(111, 'admin', '2018-12-28 04:52:07', 'Add Member kj j'),
(112, 'admin', '2018-12-28 05:00:25', 'Add Member rewrw rew'),
(113, 'admin', '2018-12-28 05:03:48', 'Add Member kj j'),
(114, 'admin', '2018-12-28 05:13:26', 'Add Member kj aaaaa'),
(115, 'admin', '2018-12-28 05:14:16', 'Delete Member kj aaaaa'),
(116, 'admin', '2018-12-28 05:14:17', 'Delete Member kjk fds'),
(117, 'admin', '2018-12-28 05:14:17', 'Delete Member kj j'),
(118, 'admin', '2018-12-28 05:14:17', 'Delete Member kj j'),
(119, 'admin', '2018-12-28 05:16:45', 'Add Member kj jkj'),
(120, 'admin', '2018-12-28 05:25:37', 'Add Member j jk'),
(121, 'admin', '2018-12-28 05:28:00', 'Add Member kj j'),
(122, 'admin', '2018-12-28 05:36:13', 'Add Member kj j'),
(123, 'admin', '2018-12-28 05:39:26', 'Delete Member kj j'),
(124, 'admin', '2018-12-28 05:39:26', 'Delete Member kj j'),
(125, 'admin', '2018-12-28 05:39:26', 'Delete Member j jk'),
(126, 'admin', '2018-12-28 05:39:26', 'Delete Member kj jkj'),
(127, 'admin', '2018-12-28 05:39:42', 'Add Member j aaaa'),
(128, 'admin', '2018-12-28 05:40:08', 'Delete Member j aaaa'),
(129, 'admin', '2018-12-28 05:40:46', 'Add Member fsdfdsfdsjfksdjf aaaaa'),
(130, 'admin', '2018-12-28 05:41:16', 'Add Member kj klj'),
(131, 'tonzkie', '2018-12-29 02:00:52', 'Add Member jk fs'),
(132, 'tonzkie', '2018-12-29 02:12:09', 'Delete Member fsdfdsfdsjfksdjf aaaaa'),
(133, 'tonzkie', '2018-12-29 02:12:09', 'Delete Member jk fs'),
(134, 'tonzkie', '2018-12-29 02:12:09', 'Delete Member kj klj'),
(135, 'tonzkie', '2018-12-29 02:23:31', 'Add Member kj j'),
(136, 'tonzkie', '2018-12-29 02:25:04', 'Add Member a aaaaa'),
(137, 'tonzkie', '2018-12-29 02:31:19', 'Add Member b b'),
(138, 'tonzkie', '2018-12-29 02:32:33', 'Add Member c cc'),
(139, 'tonzkie', '2018-12-29 02:39:09', 'Delete Member a aaaaa'),
(140, 'tonzkie', '2018-12-29 02:39:10', 'Delete Member b b'),
(141, 'tonzkie', '2018-12-29 02:39:10', 'Delete Member c cc'),
(142, 'tonzkie', '2018-12-29 02:39:10', 'Delete Member kj j'),
(143, 'tonzkie', '2018-12-29 02:39:26', 'Add Member kj a'),
(144, 'tonzkie', '2018-12-29 02:45:28', 'Add Member b b'),
(145, 'tonzkie', '2018-12-29 02:49:47', 'Add Member d d'),
(146, 'tonzkie', '2018-12-29 02:53:45', 'Add Member d ddddddddd'),
(147, 'tonzkie', '2018-12-29 02:56:08', 'Add Member e gfsd'),
(148, 'tonzkie', '2018-12-29 02:56:23', 'Delete Member kj a'),
(149, 'tonzkie', '2018-12-29 02:56:23', 'Delete Member b b'),
(150, 'tonzkie', '2018-12-29 02:56:23', 'Delete Member d d'),
(151, 'tonzkie', '2018-12-29 02:56:23', 'Delete Member d ddddddddd'),
(152, 'tonzkie', '2018-12-29 02:56:23', 'Delete Member e gfsd'),
(153, 'tonzkie', '2018-12-29 03:12:42', 'Add Member S A'),
(154, 'tonzkie', '2018-12-29 03:21:42', 'Add Member b b'),
(155, 'tonzkie', '2018-12-29 03:22:47', 'Add Member c c'),
(156, 'tonzkie', '2018-12-29 03:23:15', 'Delete Member S A'),
(157, 'tonzkie', '2018-12-29 03:23:15', 'Delete Member b b'),
(158, 'tonzkie', '2018-12-29 03:23:15', 'Delete Member c c'),
(159, 'tonzkie', '2018-12-29 03:29:02', 'Add Member a a'),
(160, 'tonzkie', '2018-12-29 03:32:51', 'Delete Member a a'),
(161, 'tonzkie', '2018-12-29 03:33:06', 'Add Member a a'),
(162, 'tonzkie', '2018-12-29 03:39:23', 'Add Member b b'),
(163, 'tonzkie', '2018-12-29 03:39:28', 'Add Dependents  '),
(164, 'tonzkie', '2018-12-29 03:43:16', 'Add Member c c'),
(165, 'tonzkie', '2018-12-29 03:44:08', 'Add Dependents  '),
(166, 'tonzkie', '2018-12-29 03:44:19', 'Add Dependents  '),
(167, 'tonzkie', '2018-12-29 03:44:24', 'Add Dependents  '),
(168, 'tonzkie', '2018-12-29 03:44:24', 'Add Dependents  '),
(169, 'tonzkie', '2018-12-29 03:46:08', 'Delete Member a a'),
(170, 'tonzkie', '2018-12-29 03:46:08', 'Delete Member b b'),
(171, 'tonzkie', '2018-12-29 03:46:08', 'Delete Member c c'),
(172, 'tonzkie', '2018-12-29 03:46:23', 'Add Member a a'),
(173, 'tonzkie', '2018-12-29 03:46:30', 'Add dependents  '),
(174, 'tonzkie', '2018-12-29 03:47:57', 'Add Member b b'),
(175, 'tonzkie', '2018-12-29 03:48:04', 'Add dependents  '),
(176, 'tonzkie', '2018-12-29 03:49:15', 'Add Member C CcCC'),
(177, 'tonzkie', '2018-12-29 03:49:22', 'Add dependents  '),
(178, 'tonzkie', '2018-12-29 03:51:50', 'Add dependents  '),
(179, 'tonzkie', '2018-12-29 03:52:58', 'Add dependents  '),
(180, 'tonzkie', '2018-12-29 03:53:21', 'Add Member D D'),
(181, 'tonzkie', '2018-12-29 03:53:25', 'Add dependents  '),
(182, 'tonzkie', '2018-12-29 03:55:24', 'Add Member e e'),
(183, 'tonzkie', '2018-12-29 06:09:27', 'Add Member v v'),
(184, 'tonzkie', '2018-12-29 06:11:03', 'Add Member b b'),
(185, 'tonzkie', '2018-12-29 06:11:19', 'Delete Member a a'),
(186, 'tonzkie', '2018-12-29 06:11:19', 'Delete Member b b'),
(187, 'tonzkie', '2018-12-29 06:11:19', 'Delete Member b b'),
(188, 'tonzkie', '2018-12-29 06:11:19', 'Delete Member C CcCC'),
(189, 'tonzkie', '2018-12-29 06:11:19', 'Delete Member D D'),
(190, 'tonzkie', '2018-12-29 06:11:19', 'Delete Member e e'),
(191, 'tonzkie', '2018-12-29 06:11:31', 'Add Member a a'),
(192, 'tonzkie', '2018-12-29 06:14:06', 'Add Member b b'),
(193, 'tonzkie', '2018-12-29 06:15:55', 'Add Member c c'),
(194, 'tonzkie', '2018-12-29 07:53:05', 'Delete Member a a'),
(195, 'tonzkie', '2018-12-29 07:53:05', 'Delete Member b b'),
(196, 'tonzkie', '2018-12-29 07:53:05', 'Delete Member c c'),
(197, 'tonzkie', '2018-12-29 07:57:19', 'Delete Member v v'),
(198, 'tonzkie', '2018-12-29 08:05:01', 'Add Member aaa aaaa'),
(199, 'tonzkie', '2018-12-29 08:23:31', 'Add Member b b'),
(200, 'tonzkie', '2018-12-29 08:51:23', 'Add Member c c'),
(201, 'admin', '2018-12-29 17:09:08', 'Delete Member aaa aaaa'),
(202, 'admin', '2018-12-29 17:09:08', 'Delete Member b b'),
(203, 'admin', '2018-12-29 17:09:08', 'Delete Member c c'),
(204, 'admin', '2018-12-29 17:09:51', 'Add Member a a'),
(205, 'admin', '2018-12-29 18:15:45', 'Add Member Thea Pulmones'),
(206, 'tonzkie', '2019-01-04 00:19:18', 'Update Member b b'),
(207, 'tonzkie', '2019-01-04 00:24:30', 'Update Member ab ab'),
(208, 'tonzkie', '2019-01-04 00:25:19', 'Update Member abababa bababa'),
(209, 'tonzkie', '2019-01-04 00:27:39', 'Add Member b b'),
(210, 'tonzkie', '2019-01-04 00:28:07', 'Update Member bc bc'),
(211, 'tonzkie', '2019-01-04 00:30:38', 'Update Member bc bc'),
(212, 'tonzkie', '2019-01-04 00:37:59', 'Update Member ac ac'),
(213, 'admin', '2019-01-04 00:53:07', 'Update Member John Kevin Loraynabbbbbbbbbb'),
(214, 'admin', '2019-01-04 00:53:24', 'Update Member abbbbb abbbbbbb'),
(215, 'admin', '2019-01-04 01:02:41', 'Update Member ab ab'),
(216, 'admin', '2019-01-04 01:02:59', 'Update Member ab ab'),
(217, 'admin', '2019-01-04 01:06:34', 'Update Member a abbb'),
(218, 'admin', '2019-01-04 01:06:44', 'Update Member a abbbb'),
(219, 'admin', '2019-01-04 01:08:39', 'Update Member b b'),
(220, 'admin', '2019-01-04 01:08:57', 'Update Member a a'),
(221, 'admin', '2019-01-04 01:09:13', 'Update Member a adddddd'),
(222, 'admin', '2019-01-04 01:32:19', 'Update Member a a'),
(223, 'admin', '2019-01-04 01:36:05', 'Add Member fdsa c'),
(224, 'tonzkie', '2019-01-05 04:05:48', 'Add Member abbbbbb abbbb'),
(225, 'tonzkie', '2019-01-05 04:08:44', 'Delete Member a a'),
(226, 'tonzkie', '2019-01-05 04:08:44', 'Delete Member abbbbbb abbbb'),
(227, 'tonzkie', '2019-01-05 04:08:44', 'Delete Member b b'),
(228, 'tonzkie', '2019-01-05 04:08:44', 'Delete Member fdsa c'),
(229, 'tonzkie', '2019-01-05 04:08:55', 'Update Member John Kevin aaaaaaaaa'),
(230, 'tonzkie', '2019-01-05 04:09:49', 'Update Member John Kevin Loraynaafdasfdasfasdfsda'),
(231, 'tonzkie', '2019-01-05 04:13:25', 'Update Member John Kevin Loraynaaaaaaaa'),
(232, 'tonzkie', '2019-01-05 04:13:46', 'Add Member a a'),
(233, 'tonzkie', '2019-01-05 04:14:03', 'Update Member a abbbbb'),
(234, 'tonzkie', '2019-01-05 04:19:17', 'Update Member abbbb abbbbbbbb'),
(235, 'tonzkie', '2019-01-05 04:19:46', 'Update Member John Kevin ababa'),
(236, 'tonzkie', '2019-01-06 01:26:41', 'Add Member a abbbb'),
(237, 'tonzkie', '2019-01-06 01:36:38', 'Update Member a accccc'),
(238, 'tonzkie', '2019-01-06 01:37:09', 'Update Member a acccccbbbb'),
(239, 'tonzkie', '2019-01-06 01:56:44', 'Update Member a acccccbbbbdd'),
(240, 'tonzkie', '2019-01-06 01:57:00', 'Update Member a acccccbbbbdddd'),
(241, 'tonzkie', '2019-01-06 01:57:27', 'Delete Member a acccccbbbb'),
(242, 'tonzkie', '2019-01-06 01:57:27', 'Delete Member a acccccbbbb'),
(243, 'tonzkie', '2019-01-06 01:57:27', 'Delete Member a acccccbbbb'),
(244, 'tonzkie', '2019-01-06 01:57:27', 'Delete Member a acccccbbbb'),
(245, 'tonzkie', '2019-01-06 01:57:27', 'Delete Member a acccccbbbb'),
(246, 'tonzkie', '2019-01-06 01:57:27', 'Delete Member a acccccbbbb'),
(247, 'tonzkie', '2019-01-06 01:59:04', 'Update Member a acccccbbbbdddd'),
(248, 'tonzkie', '2019-01-06 01:59:59', 'Update Member a acccccbbbbddddeee'),
(249, 'tonzkie', '2019-01-06 02:00:14', 'Update Member a acccccbbbbddddeeee'),
(250, 'tonzkie', '2019-01-06 02:01:43', 'Update Member adddd acccccbbbbdddd'),
(251, 'tonzkie', '2019-01-06 02:03:41', 'Update Member adddd acccccbbbbdddd'),
(252, 'tonzkie', '2019-01-06 02:04:03', 'Update Member adddddd acccccbbbbdddd'),
(253, 'tonzkie', '2019-01-06 02:05:56', 'Update Member addddd acccccbbbbdddd'),
(254, 'tonzkie', '2019-01-06 02:06:06', 'Update Member addddd acccccbbbbdddd'),
(255, 'tonzkie', '2019-01-06 02:08:52', 'Add Member c c'),
(256, 'tonzkie', '2019-01-06 02:09:10', 'Update Member c cbbbbbb'),
(257, 'tonzkie', '2019-01-06 02:09:23', 'Update Member adddddddd acccccbbbbdddd'),
(258, 'tonzkie', '2019-01-06 02:12:25', 'Update Member luna juan'),
(259, 'tonzkie', '2019-01-06 02:13:09', 'Update Member luna juan'),
(260, 'tonzkie', '2019-01-06 02:15:50', 'Update Member luna juan'),
(261, 'tonzkie', '2019-01-06 02:17:59', 'Update Member luna juan'),
(262, 'tonzkie', '2019-01-06 02:19:17', 'Update Member luna juan'),
(263, 'tonzkie', '2019-01-06 02:20:29', 'Update Member luna juan'),
(264, 'tonzkie', '2019-01-06 02:23:27', 'Update Member luna juan'),
(265, 'tonzkie', '2019-01-06 02:25:31', 'Update Member luna juan'),
(266, 'tonzkie', '2019-01-06 02:29:33', 'Update Member luna juan'),
(267, 'tonzkie', '2019-01-06 02:30:52', 'Update Member luna juan'),
(268, 'tonzkie', '2019-01-06 02:32:12', 'Update Member luna juan'),
(269, 'tonzkie', '2019-01-06 02:33:51', 'Update Member luna juanbababa'),
(270, 'tonzkie', '2019-01-06 02:39:40', 'Update Member luna juan'),
(271, 'tonzkie', '2019-01-06 02:40:05', 'Update Member luna juan'),
(272, 'tonzkie', '2019-01-06 02:42:36', 'Update Member luna juanbbb'),
(273, 'tonzkie', '2019-01-11 02:21:55', 'Update Member luna aaaaaa'),
(274, 'tonzkie', '2019-01-11 02:23:10', 'Update Member luna aaaa'),
(275, 'tonzkie', '2019-01-11 02:29:10', 'Update Member luna aaaabababa'),
(276, 'tonzkie', '2019-01-11 02:30:52', 'Update Member luna cccc'),
(277, 'tonzkie', '2019-01-11 02:31:33', 'Update Member luna aaaa'),
(278, 'tonzkie', '2019-01-11 02:31:46', 'Update Member luna ccc'),
(279, 'tonzkie', '2019-01-11 02:35:59', 'Update Member luna aaaa'),
(280, 'admin', '2019-01-11 02:39:04', 'Edit Program Coordinator f4 Sablan'),
(281, 'admin', '2019-01-11 02:39:22', 'Edit Program Coordinator robertson Sablan'),
(282, 'admin', '2019-01-11 02:42:12', 'Edit Program Coordinator robertson Sablan'),
(283, 'admin', '2019-01-11 02:50:50', 'Update Member luna bbbb'),
(284, 'admin', '2019-01-11 02:51:43', 'Update Member luna ddddd'),
(285, 'admin', '2019-01-11 03:00:48', 'Update Member luna aaaa'),
(286, 'admin', '2019-01-11 03:08:34', 'Update Member luna ddd'),
(287, 'admin', '2019-01-11 03:10:27', 'Update Member luna ddd'),
(288, 'admin', '2019-01-11 03:12:33', 'Update Member luna ddd'),
(289, 'admin', '2019-01-11 03:13:13', 'Update Member luna ddd'),
(290, 'admin', '2019-01-11 03:13:22', 'Update Member luna ddd'),
(291, 'admin', '2019-01-11 03:16:39', 'Update Member luna aaaa'),
(292, 'admin', '2019-01-11 03:20:02', 'Delete Member luna aaaa'),
(293, 'admin', '2019-01-11 03:21:14', 'Update Member luna ddd'),
(294, 'admin', '2019-01-11 03:23:54', 'Update Member luna ddd'),
(295, 'admin', '2019-01-11 03:24:05', 'Update Member luna bbbb'),
(296, 'admin', '2019-01-11 03:28:02', 'Update Member luna aaaa'),
(297, 'admin', '2019-01-11 03:31:55', 'Update Member luna bababa'),
(298, 'admin', '2019-01-11 03:44:59', 'Update Member luna aaa'),
(299, 'admin', '2019-01-11 03:45:29', 'Update Member luna aababa'),
(300, 'admin', '2019-01-11 03:47:18', 'Update Member luna Juan'),
(301, 'admin', '2019-01-11 03:47:40', 'Update Member luna Juan'),
(302, 'admin', '2019-01-11 03:48:46', 'Update Member luna Juan'),
(303, 'admin', '2019-01-11 03:50:20', 'Update Member Rodrigez Jecel'),
(304, 'admin', '2019-01-11 03:51:23', 'Update Member Lito Lapid'),
(305, 'admin', '2019-01-11 03:51:45', 'Delete Member luna Juan'),
(306, 'admin', '2019-01-11 03:51:45', 'Delete Member luna Juan'),
(307, 'admin', '2019-01-11 03:51:45', 'Delete Member luna Juan'),
(308, 'admin', '2019-01-11 03:51:45', 'Delete Member luna Juan'),
(309, 'admin', '2019-01-11 03:51:45', 'Delete Member luna Juan'),
(310, 'admin', '2019-01-11 03:51:45', 'Delete Member luna Juan'),
(311, 'admin', '2019-01-11 03:51:45', 'Delete Member luna Juan'),
(312, 'admin', '2019-01-11 03:52:24', 'Update Member Rodrigez Jecel'),
(313, 'admin', '2019-01-11 04:07:29', 'Add Member j jk'),
(314, 'admin', '2019-01-11 04:07:55', 'Update Member j bbbbbb');

-- --------------------------------------------------------

--
-- Table structure for table `dependents`
--

CREATE TABLE `dependents` (
  `dependent_id` int(11) NOT NULL,
  `dependent_givenname` varchar(100) NOT NULL,
  `dependent_surname` varchar(100) NOT NULL,
  `dependent_middlename` varchar(100) NOT NULL,
  `birthdate` varchar(100) NOT NULL,
  `relationship` varchar(100) NOT NULL,
  `member_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dependents`
--

INSERT INTO `dependents` (`dependent_id`, `dependent_givenname`, `dependent_surname`, `dependent_middlename`, `birthdate`, `relationship`, `member_id`) VALUES
(3, 'k', 'k', 'k', 'k', 'k', 24),
(4, 'l', 'l', 'l', 'l', 'l', 24),
(5, 'q', 'q', 'q', 'q', 'q', 24),
(6, 'q', 'q', 'q', 'q', 'q', 24),
(10, 'm', 'g', 'k', 'f', 'h', 23),
(11, 'j', 'l', 'r', 'k', 'p', 10),
(12, 'm', '', '', '', '', 10),
(13, 'q', 'q', 'q', 'q', '', 24),
(14, 'q', 'q', 'q', 'q', '', 24),
(17, 'm', 'm', 'm', 'm', 'm', 25),
(18, 'l', 'l', 'l', 'l', 'l', 25),
(19, 'k', 'k', 'k', 'k', 'k', 25),
(20, 'q', 'q', 'q', 'q', 'q', 26),
(21, 'm', 'm', 'm', 'm', 'm', 26),
(22, 'k', 'u', 'u', 'u', 'u', 26),
(23, 'k', 'k', 'k', 'k', 'k', 23),
(24, '', '', '', '', 'relationship', 0),
(25, '', '', '', '', 'relationship', 0),
(26, '', '', '', '', 'relationship', 0),
(27, '', '', '', '', 'relationship', 0),
(28, '', '', '', '', 'relationship', 0),
(29, '', '', '', '', 'C', 0),
(30, '', '', '', '', '', 0),
(31, '', '', '', '', '', 0),
(32, '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `member_id` int(11) NOT NULL,
  `card_number` varchar(100) NOT NULL,
  `given_name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `middlename` varchar(20) NOT NULL,
  `sex` varchar(6) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `age` int(11) NOT NULL,
  `itemname` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `kilogram` int(100) NOT NULL,
  `totalpayment` double NOT NULL,
  `rec_fname` varchar(100) NOT NULL,
  `rec_lname` varchar(100) NOT NULL,
  `rec_mname` varchar(100) NOT NULL,
  `rec_address` varchar(100) NOT NULL,
  `rec_contact` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `card_number`, `given_name`, `surname`, `middlename`, `sex`, `address`, `contact_no`, `postal_code`, `age`, `itemname`, `quantity`, `kilogram`, `totalpayment`, `rec_fname`, `rec_lname`, `rec_mname`, `rec_address`, `rec_contact`) VALUES
(18, '3', 'Lito', 'Lapid', 'D', 'Male', 'Metro Manila', '09338725932', '6000', 43, 'TSHIRT', 'quantity', 10, 200, 'Thea', 'Alonso', 'A', 'Bogo Cebu City', 0),
(20, '352433', 'Rodrigez', 'Jecel', 'R', 'Male', 'Sanciangko St. Cebu City', '09338725945', '6000', 43, 'TSHIRT', 'quantity', 10, 200, 'Thea', 'Alonso', 'A', 'Bogo Cebu City', 0),
(24, '3', 'luna', 'Juan', 'a', 'Male', 'Sanciangko St. Cebu City', '09338725932', '6000', 43, 'TSHIRT', 'quantity', 10, 200, 'Thea', 'Alonso', 'A', 'Bogo Cebu City', 0),
(79, '432432', 'j', 'bbbbbb', 'kj', 'Male', 'k', 'jk', 'jk', 32, 'kj', 'quantity', 0, 0, 'jk', 'jk', 'j', 'kj', 0);

-- --------------------------------------------------------

--
-- Table structure for table `program_coordinator`
--

CREATE TABLE `program_coordinator` (
  `program_coordinator_id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `program_coordinator_in` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `program_coordinator`
--

INSERT INTO `program_coordinator` (`program_coordinator_id`, `firstname`, `lastname`, `username`, `password`, `program_coordinator_in`, `status`) VALUES
(7, 'robertson', 'Sablan', 'xiaq', 'xiaq', 'Negros Occidental Provincial Hospital', ''),
(9, 'Achilles', 'Palma', 'Aki', 'Aki', 'Cadiz City Hospital', ''),
(10, 'Stephanie', 'Villanueva', 'tephai', 'tephai', 'E.B Magalona Hospital', ''),
(12, 'fds', 'fds', 'fds', 'fds', 'ffdsfds', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `class_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `firstname`, `lastname`, `class_id`, `username`, `password`, `location`, `status`) VALUES
(113, 'Clifford', 'Ledesma', 13, '21100324', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(112, 'Raymond', 'Serion', 13, '2700372', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(111, 'Mark Dominic', 'Sayon', 13, '21100867', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(108, 'Kaye Angela', 'Cueva', 13, '21101151', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(105, 'Neljie', 'Guirnela', 13, '21101131', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(106, 'Razel', 'Palermo', 13, '29000676', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(103, 'Jade', 'Gordoncillo', 13, '21100617', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(104, 'Felix Kirby', 'Ubas', 13, '21100277', 'lms10117', 'uploads/1238763_688342754527339_915323123_n.jpg', 'Unregistered'),
(100, 'Jamilah', 'Lonot', 13, '21100303', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(101, 'Xenia Jane', 'Billones', 13, '21100318', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(102, 'Carell', 'Catuburan', 13, '21101124', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(97, 'Mary Joy', 'Lambosan', 13, '20101289', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(98, 'Christine Joy', 'Macaya', 13, '21100579', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(95, 'Ergin Joy', 'Satoc', 13, '21101142', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(93, 'John Kevin ', 'Lorayna', 7, '111', 'teph', 'uploads/3094_384893504898082_1563225657_n.jpg', 'Registered'),
(94, 'Leah Mae', 'Padilla', 13, '21100471', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(76, 'Jamaica Mae', 'Alipe', 13, '21100555', '123', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Registered'),
(107, 'Jose Harry', 'Polondaya', 13, '29001002', 'florypis', 'uploads/29001002.jpg', 'Registered'),
(110, 'Zyryn', 'Corugda', 13, '21100881', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(109, 'Rena', 'Lamberto', 13, '29001081', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(99, 'Ryan Teofilo', 'Malbata-an', 13, '21100315', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(96, 'Glecy Marie', 'Navarosa', 13, '20101436', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(75, 'Miralyn', 'Pabalate', 13, '21100855', 'em', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(74, 'Ma. Nonie', 'Mendoza', 13, '21100913', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(73, 'Stephanie', 'Villanueva', 13, '21101042', 'tephai', 'uploads/3094_384893504898082_1563225657_n.jpg', 'Registered'),
(72, 'Jayvon', 'Pig-ao', 13, '21100547', 'test', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(71, 'Noli', 'Mendoza', 13, '21100556', 'noledel', 'uploads/Africa.jpg', 'Registered'),
(134, 'Victor Anthony', 'Jacobo', 12, '21101050', 'akositon', 'uploads/win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif', 'Registered'),
(135, 'Albert Kezzel', 'Naynay', 14, '20101361', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(136, 'Jorgielyn', 'Serfino', 7, '20100331', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(137, 'Wina Mae', 'Espenorio', 8, '20100447', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(138, 'Brian Paul', 'Sablan', 7, '29000557', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(139, 'Rodzil', 'Camato', 7, '20100RC', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(140, 'Dean Martin', 'Tingson', 14, '21100665', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(141, 'Jared Reu', 'Windam', 15, '21100695', 'iloveyoujam', 'uploads/1463666_678111108874417_1795412912_n.jpg', 'Registered'),
(142, 'Lee Ann', 'Vertucio', 12, '21100351', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(143, 'Danica', 'Lamis', 12, '21100396', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(144, 'Neovi', 'Devierte', 12, '21100557', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(145, 'Eril Pio', 'Mercado', 12, '21100291', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(146, 'Johnedel', 'Bauno', 12, '21100411', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(147, 'Jerwin', 'Delos Reyes', 12, '21100369', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(148, 'Jendrix', 'Victosa', 12, '21100431', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(149, 'Jebson', 'Tordillos', 12, '21100406', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(150, 'Jethro', 'Pansales', 12, '21101273', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(151, 'Karyl June', 'Bacobo', 12, '21100895', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(152, 'Kristelle Shaine', 'Rubi', 12, '21101063', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(153, 'Richelle', 'Villarmia', 12, '20101392', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(154, 'Mae Ann', 'Panugaling', 12, '21100904', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(155, 'Ma. Roxette', 'Infante', 12, '21100421', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(156, 'Savrena Joy', 'Rael', 12, '2100287', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(157, 'Ace John', 'Casuyon', 12, '21100393', 'DianaraSayon', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Registered'),
(158, 'Rose Mae', 'Pido', 12, '21101195', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(159, 'Mary Ann', 'Panaguiton', 12, '21100701', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(162, 'kimberly kaye', 'salvatierra', 14, '21101182', 'kimzteng', 'uploads/29001002.jpg', 'Registered'),
(164, 'Alit', 'Arvin', 14, '20101605', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(165, 'Ana Mae', 'Alquizar', 14, '21100785', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(166, 'Thessalonica', 'Arroz', 14, '21100651', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(167, 'Leslie', 'Campo', 14, '21100265', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(168, 'Ace', 'Casolino', 14, '27000921', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(169, 'Michael Jed', 'Flores', 14, '21100820', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(172, 'Hennie Rose', 'Laz', 14, '21100805', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(171, 'Joy', 'Macahilig', 14, '21100464', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(173, 'Ma. Nieva', 'Manuel ', 14, '21100711', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(174, 'Devina', 'Navarro', 14, '21100711', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(175, 'Aimee', 'Orlido', 14, '21100654', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(176, 'Mary Grace', 'Quizan', 14, '21100772', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(177, 'John Christopher', 'Reguindin', 14, '21100418', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(178, 'Mary Ann', 'Somosa', 14, '21101150', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(179, 'Marrianne', 'Tumala', 14, '21100710', 'test', 'uploads/win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif', 'Registered'),
(180, 'Deo Christopher', 'Tribaco', 14, '21101227', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(181, 'Jerson', 'Vargas', 14, '21100819', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(182, 'Valencia', 'Jeralice', 14, '29000405', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(183, 'Cristine', 'Yanson', 14, '21101148', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(184, 'Ariane', 'Alix', 17, '21201166', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(185, 'Mark Arvin', 'Arandilla', 17, '21201453', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(186, 'Ryan Carl', 'Biaquis', 17, '21201244', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(187, 'Ria', 'Bitar', 17, '21201282', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(188, 'Jeremae', 'Bustamante', 17, '21200798', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(189, 'Rhen Mark', 'Callado', 17, '21201012', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(190, 'Ma. Geraldine', 'Carisma', 17, '21201219', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(191, 'Jenny', 'Casapao', 17, '21200855', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(192, 'Welson', 'Castro', 17, '120733', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(193, 'Kimberly Hope', 'Centina', 17, '21201338', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(194, 'Sandra', 'Gomez', 17, '21201335', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(195, 'Dona Jean', 'Guardialao', 17, '21201113', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(196, 'Jeara Mae', 'Guttierrez', 17, '21200782', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(197, 'Mary Joy', 'Jimenez', 17, '21201437', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(198, 'Cyril', 'Lambayong', 17, '21201163', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(199, 'Angelie', 'Lape', 17, '21201356', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(200, 'Jamine', 'Navarosa', 17, '21201115', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(201, 'Allen Joshua', 'Nicor', 17, '21201430', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(202, 'Charis', 'Onate', 17, '21200984', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(203, 'Ikea', 'Padonio', 17, '20100527', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(204, 'Marissa', 'Pasco', 17, '21200935', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(205, 'Kenneth', 'Sayon', 17, '21201268', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(206, 'Mary Grace', 'Morales', 14, '21100293', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(207, 'Danica', 'Delarmente', 14, '21100613', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(208, 'Irish Dawn', 'Belo', 19, '21300413', 'olebirish', 'uploads/Desert.jpg', 'Registered');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `firstname`, `lastname`) VALUES
(14, 'jkev', 'jkev', 'john kevin', 'lorayna'),
(16, 'admin', 'admin', 'admin', 'admin'),
(18, 'tonzkie', 'meldre013', 'anthony', 'Melendres'),
(19, 'employee', 'employee', 'thea', 'pulmones');

-- --------------------------------------------------------

--
-- Table structure for table `user_log`
--

CREATE TABLE `user_log` (
  `user_log_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `login_date` varchar(30) NOT NULL,
  `logout_date` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_log`
--

INSERT INTO `user_log` (`user_log_id`, `username`, `login_date`, `logout_date`, `user_id`) VALUES
(1, 'jkev', '2014-01-22 21:45:22', '2014-02-04 15:25:13', 14),
(2, 'jkev', '2014-01-23 12:20:35', '2014-02-04 15:25:13', 14),
(3, 'xia', '2014-01-23 12:27:33', '2014-01-24 10:45:32', 7),
(4, 'jkev', '2014-01-23 12:28:21', '2014-02-04 15:25:13', 14),
(5, 'jkev', '2014-01-23 12:31:36', '2014-02-04 15:25:13', 14),
(6, 'jkev', '2014-01-23 13:00:16', '2014-02-04 15:25:13', 14),
(7, 'xia', '2014-01-24 10:45:21', '2014-01-24 10:45:32', 7),
(8, 'jkev', '2014-01-24 10:45:57', '2014-02-04 15:25:13', 14),
(9, 'jkev', '2014-01-25 10:48:29', '2014-02-04 15:25:13', 14),
(10, 'jkev', '2014-01-25 16:54:46', '2014-02-04 15:25:13', 14),
(11, 'jkev', '2014-01-25 16:55:00', '2014-02-04 15:25:13', 14),
(12, 'jkev', '2014-01-26 19:14:57', '2014-02-04 15:25:13', 14),
(13, 'aki', '2014-01-26 19:44:23', '2014-02-04 15:26:05', 9),
(14, 'jkev', '2014-01-27 10:44:47', '2014-02-04 15:25:13', 14),
(15, 'jkev', '2014-01-30 13:30:50', '2014-02-04 15:25:13', 14),
(16, 'jkev', '2014-01-30 13:31:34', '2014-02-04 15:25:13', 14),
(17, 'aki', '2014-01-30 13:31:56', '2014-02-04 15:26:05', 9),
(18, 'jkev', '2014-01-30 16:50:21', '2014-02-04 15:25:13', 14),
(19, 'aki', '2014-01-31 10:16:20', '2014-02-04 15:26:05', 9),
(20, 'jkev', '2014-01-31 10:17:46', '2014-02-04 15:25:13', 14),
(21, 'jkev', '2014-02-04 15:14:33', '2014-02-04 15:25:13', 14),
(22, 'jkev', '2014-02-04 15:21:45', '2014-02-04 15:25:13', 14),
(23, 'aki', '2014-02-04 15:25:21', '2014-02-04 15:26:05', 9),
(24, 'jkev', '2014-02-04 15:26:28', '', 14),
(25, 'admin', '2018-09-21 04:59:26', '2019-01-11 04:15:59', 16),
(26, 'admin', '2018-12-12 07:29:26', '2019-01-11 04:15:59', 16),
(27, 'admin', '2018-12-22 02:46:28', '2019-01-11 04:15:59', 16),
(28, 'admin', '2018-12-22 02:46:29', '2019-01-11 04:15:59', 16),
(29, 'tonzkie', '2018-12-22 02:55:49', '2018-12-29 03:13:36', 18),
(30, 'admin', '2018-12-22 02:56:43', '2019-01-11 04:15:59', 16),
(31, 'admin', '2018-12-26 05:10:52', '2019-01-11 04:15:59', 16),
(32, 'admin', '2018-12-27 01:57:05', '2019-01-11 04:15:59', 16),
(33, 'employee', '2018-12-27 01:58:45', '2018-12-27 05:45:53', 19),
(34, 'admin', '2018-12-27 05:45:58', '2019-01-11 04:15:59', 16),
(35, 'admin', '2018-12-27 06:00:49', '2019-01-11 04:15:59', 16),
(36, 'admin', '2018-12-28 04:36:16', '2019-01-11 04:15:59', 16),
(37, 'tonzkie', '2018-12-28 04:36:35', '2018-12-29 03:13:36', 18),
(38, 'admin', '2018-12-28 04:37:19', '2019-01-11 04:15:59', 16),
(39, 'tonzkie', '2018-12-29 01:38:43', '2018-12-29 03:13:36', 18),
(40, 'tonzkie', '2018-12-29 03:14:05', '', 18),
(41, 'admin', '2018-12-29 08:28:42', '2019-01-11 04:15:59', 16),
(42, 'admin', '2018-12-29 08:30:43', '2019-01-11 04:15:59', 16),
(43, 'admin', '2018-12-29 08:38:12', '2019-01-11 04:15:59', 16),
(44, 'tonzkie', '2018-12-29 08:38:49', '', 18),
(45, 'admin', '2018-12-29 17:06:53', '2019-01-11 04:15:59', 16),
(46, 'tonzkie', '2018-12-29 17:10:27', '', 18),
(47, 'admin', '2018-12-29 17:44:49', '2019-01-11 04:15:59', 16),
(48, 'tonzkie', '2019-01-03 01:28:53', '', 18),
(49, 'tonzkie', '2019-01-04 00:19:00', '', 18),
(50, 'admin', '2019-01-04 00:43:06', '2019-01-11 04:15:59', 16),
(51, 'admin', '2019-01-04 01:33:25', '2019-01-11 04:15:59', 16),
(52, 'admin', '2019-01-04 01:36:37', '2019-01-11 04:15:59', 16),
(53, 'tonzkie', '2019-01-05 04:00:14', '', 18),
(54, 'tonzkie', '2019-01-06 01:16:03', '', 18),
(55, 'tonzkie', '2019-01-11 02:21:31', '', 18),
(56, 'admin', '2019-01-11 02:38:40', '2019-01-11 04:15:59', 16),
(57, 'admin', '2019-01-11 04:16:15', '', 16),
(58, 'tonzkie', '2019-01-11 04:16:57', '', 18);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`activity_log_id`);

--
-- Indexes for table `dependents`
--
ALTER TABLE `dependents`
  ADD PRIMARY KEY (`dependent_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `program_coordinator`
--
ALTER TABLE `program_coordinator`
  ADD PRIMARY KEY (`program_coordinator_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_log`
--
ALTER TABLE `user_log`
  ADD PRIMARY KEY (`user_log_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `activity_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=315;
--
-- AUTO_INCREMENT for table `dependents`
--
ALTER TABLE `dependents`
  MODIFY `dependent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT for table `program_coordinator`
--
ALTER TABLE `program_coordinator`
  MODIFY `program_coordinator_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `user_log`
--
ALTER TABLE `user_log`
  MODIFY `user_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
